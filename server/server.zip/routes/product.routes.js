const router = require('express').Router()
const productController = require('../controller/product.controller')
router.post('/createPr',productController.createProduct)

module.exports = router