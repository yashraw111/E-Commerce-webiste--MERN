const ProductSchema = require('../model/product.model')

const createProduct = async(req,res)=>{
    console.log(req.body)
}


module.exports = {createProduct}